import React, { useState } from "react";
import namesData from "./data/names.json";

function App() {
  const [parent, setParent] = useState("");
  const [gender, setGender] = useState("male");
  const [results, setResults] = useState([]);

  const handleFind = () => {
    const list = namesData[gender];
    const filtered = list.filter(item =>
      item.name.toLowerCase().includes(parent.toLowerCase().slice(0, 2))
    );
    setResults(filtered.length ? filtered : list.slice(0, 5));
  };

  return (
    <div className="max-w-md mx-auto mt-10 p-6 shadow-lg bg-white rounded">
      <h1 className="text-2xl font-bold mb-4 text-center">Muslim Baby Name Finder</h1>

      <input
        type="text"
        placeholder="পিতার বা মাতার নাম লিখুন"
        value={parent}
        onChange={e => setParent(e.target.value)}
        className="w-full p-2 mb-4 border rounded"
      />

      <select
        value={gender}
        onChange={e => setGender(e.target.value)}
        className="w-full p-2 mb-4 border rounded"
      >
        <option value="male">ছেলের নাম</option>
        <option value="female">মেয়ের নাম</option>
      </select>

      <button
        onClick={handleFind}
        className="w-full bg-green-600 text-white p-2 rounded mb-4"
      >
        Find Name
      </button>

      {results.length > 0 && (
        <div>
          <h2 className="text-lg font-semibold mb-2">সাজেস্টেড ইসলামিক নাম:</h2>
          <ul className="space-y-2">
            {results.map((item, idx) => (
              <li key={idx} className="p-2 border rounded">
                <strong>{item.name}</strong> — {item.meaning}
                {item.ayat && <span> (Surah Ayat: {item.ayat})</span>}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}

export default App;
